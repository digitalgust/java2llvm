package classparser;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Parses and stores the fields from Java .class file
 *
 * @author Deshan Dissanayake
 */

public class Method {

    /* Method info variables */
    private int             accessFlags;
    private int             nameIndex;
    private int             descriptorIndex;
    private int             attributesCount;
    private Attribute       attributes[];

    /* Other local variables */
    private MethodFormatter mf;
    private String          accessModifier;
    private String          methodName;
    private String          descriptor;
    private String          returnType;
    private List<String>    parameters;
    private CPEntry         cpEntry;
    private ConstantUtf8    constantUtf8;


    public Method(DataInputStream dis, ConstantPool cp) throws IOException, InvalidConstantPoolIndex {

        mf = new MethodFormatter();

        /* Parsing access and property modifier */
        accessFlags = dis.readUnsignedShort();
        accessModifier = mf.setModifier(accessFlags);

        /* Parsing the method name */
        nameIndex = dis.readUnsignedShort();
        cpEntry = cp.getEntry(nameIndex);
        if (cpEntry instanceof ConstantUtf8) {
            constantUtf8 = (ConstantUtf8) cpEntry;
            methodName = new String(constantUtf8.getBytes());
            //if (!methodName.equals("<init>")) methodName += "()";    // enable () front of method except <init>. uncomment if want
        }

        /* Parsing the method descriptor */
        descriptorIndex = dis.readUnsignedShort();
        cpEntry = cp.getEntry(descriptorIndex);
        if (cpEntry instanceof ConstantUtf8) {
            constantUtf8 = (ConstantUtf8) cpEntry;
            descriptor = constantUtf8.getBytes();

            /* Parse return type & parameters */
            returnType = mf.parseReturnType(descriptor);
            parameters = mf.parseParameters(descriptor);
        }

        /* Parsing the method attributes */
        attributesCount = dis.readUnsignedShort();
        attributes = new Attribute[attributesCount];
        for (int i = 0; i < attributesCount; i++) {
            attributes[i] = new Attribute(dis, cp);
        }

    }



    /**
     * =======================================================================
     * Getters and Setters
     * =======================================================================
     */

    public String getMethodName() {
        return methodName;
    }

    public String getReturnType() {
        return returnType;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public Attribute[] getAttributes() {
        return attributes;
    }
}
