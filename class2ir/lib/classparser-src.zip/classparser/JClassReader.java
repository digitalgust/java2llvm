package classparser;
/**
 * Main class of the program. Check for the valid user inputs and
 * call the appropriate methods
 *
 * @author Deshan Dissanayake
 */

public class JClassReader {

    private static final String OPTION_M = "-m";
    private static final String OPTION_C = "-c";
    private static final String OPTION_O = "-o";
    private static final String OPTION_P = "-p";
    private static final String USAGE    = "Usage: java JClassReader [-m|-c|-o|-p] <class-file>";

    private static ClassHelper classHelper;

    private static String      option;        /* User option. should be either -m, -c, -o or -p */
    private static String[]    files;         /* Holds user entered file(s)/directory(ies) */

    public static void main(String[] args) {

        /* Check for arguments */
        if (args.length < 1) {
            System.out.println(USAGE);
            System.exit(-1);
        }

        /* Assign the first argument to 'option' */
        option = args[0];

        /* Copy all arguments to 'file' but the 1st */
        files = new String[args.length-1];
        for (int i=1; i<args.length; i++){
            files[i-1] = args[i];
        }

        /* Creates an object from FileHelper class while passing the values to the constructor */
        classHelper = new ClassHelper(option, files);

        /* Validates arguments and starts the operation */
        switch (option) {
            case OPTION_M:
                classHelper.openClasses();
                classHelper.printMethods();
                break;
            case OPTION_C:
                classHelper.openClasses();
                classHelper.printCalls();
                break;
            case OPTION_O:
                classHelper.openClasses();
                classHelper.printOverrides();
                break;
            case OPTION_P:
                classHelper.openClasses();
                classHelper.printPolymorphism();
                break;
            default:
                System.out.println(USAGE);
                System.exit(-1);
        }

    }
}
