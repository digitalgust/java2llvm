package classparser;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Open the user specified class and output the information
 *
 * @author Deshan Dissanayake
 */

public class ClassHelper {

    private static String IS_SUPER_CLASS = "java/lang/Object";
    private static String INVOKE_SPECIAL = "invokespecial";

    private FileHelper      fileHelper;

    private String          option;                      /* User option. should be either -m, -c, -o or -p */
    private String[]        files;                       /* Holds user entered file(s)/directory(ies) */
    private List<String>    fileList;                    /* Validated and extracted file list with their absolute paths */
    private ClassFile       classFile;                   /* Holds all the data about a .class file */
    private List<ClassFile> classFileList;               /* A list of all ClassFile objects created during the runtime. i.e. all inputted classes */
    private List<String>    thisClassList;               /* List which holds the current parsing class */
    private List<String>    superClassList;              /* List which holds super class of current parsing class */




    public ClassHelper(String option, String[] files) {
        this.option = option;
        this.files = files;

        fileHelper = new FileHelper();
        fileList = new ArrayList<>();
        classFileList = new ArrayList<>();
        thisClassList = new ArrayList<>();
        superClassList = new ArrayList<>();
    }



    /**
     * Open and parse all the classes given
     */
    public void openClasses () {

        fileHelper.openFile(files);
        fileList = fileHelper.getFileList();

        for (Object o : fileList) {

            try {

                classFile = new ClassFile(o.toString(), option);
                classFileList.add(classFile);

            } catch (ClassFileParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    public ClassFile getClassFile(String className){
        for(ClassFile cf:classFileList){

            if(cf.getThisClassName().equals(className)){
                return cf;
            }
        }
        return null;
    }


    /**
     * Print details about the methods.
     * this will print Method name, Return type,
     * Parameters and return type
     */
    public void printMethods () {

        double totalMethodSize;
        double averageMethodSize;

        for (ClassFile cf : classFileList) {

            totalMethodSize = 0;
            averageMethodSize = 0;

            printHeader(cf);

            for (Method m : cf.getMethods()) {

                System.out.printf("\n\t\tMethod name: %s\n",
                        m.getMethodName());

                System.out.printf("\t\tReturn type: %s\n",
                        m.getReturnType());

                System.out.printf("\t\tParameters:  %s\n",
                        m.getParameters());

                if (m.getAttributes().length == 0) {

                    System.out.printf("\t\tMethod size: 0 bytes\n");

                } else {

                    for (Attribute a : m.getAttributes()) {

                        if (a.getAttributeName().equals("Code")) {

                            System.out.printf("\t\tMethod size: %s bytes\n",
                                    a.getAttributeLength());

                            totalMethodSize += a.getAttributeLength();
                        }
                    }
                }
            }

            averageMethodSize = (cf.getMethodsCount() > 0) ? totalMethodSize/cf.getMethodsCount() : 0;

            System.out.printf("\n\tAverage method size: %.2f ≃ %d bytes\n",
                    averageMethodSize, Math.round((float)averageMethodSize));

            printFooter();
        }
    }



    /**
     * Print number of method calls make by each method
     * and the average number of method calls per each class
     */
    public void printCalls () {

        double totalMethodCalls;
        double averageMethodCalls;

        for (ClassFile cf : classFileList) {

            totalMethodCalls = 0;
            averageMethodCalls = 0;

            printHeader(cf);

            for (Method m : cf.getMethods()) {

                System.out.printf("\n\t\tMethod name          : %s\n",
                        m.getMethodName());

                if (m.getAttributes().length == 0) {

                    System.out.printf("\t\tMethod calls count   : N/A \n");

                } else {

                    for (Attribute a : m.getAttributes()) {

                        if (a.getCodeAttribute() != null) {

                            System.out.printf("\t\tMethod calls count   : %s\n",
                                    a.getCodeAttribute().getInvokeCountPerMethod());

                            if (a.getCodeAttribute().getInvokeCountPerMethod()>0) {

                                System.out.printf("\t\tBeen called method(s): ");

                                for (Object o : a.getCodeAttribute().getBeingCalledMethodSignatures()) {
                                    System.out.printf("%s  ", o.toString());
                                }

                                System.out.print("\n");
                            }

                            totalMethodCalls += a.getCodeAttribute().getInvokeCountPerMethod();    
                        }
                    }
                }
            }

            averageMethodCalls = (cf.getMethodsCount() > 0) ? totalMethodCalls/cf.getMethodsCount() : 0;

            System.out.printf("\n\tAverage method calls: %.2f ≃ %d per method\n",
                    averageMethodCalls, Math.round((float)averageMethodCalls));

            printFooter();
        }
    }



    /**
     * Prints list of descendant classes that contains
     * override for each method and average method overrides
     */
    public void printOverrides () {

        double totalMethodOverrides;
        double averageMethodOverrides;

        for (ClassFile cf : classFileList) {

            totalMethodOverrides = 0;
            averageMethodOverrides = 0;

            printHeader(cf);

            System.out.printf("\n\tThis class: %s\n",
                    cf.getThisClassName());

            thisClassList.add(cf.getThisClassName());

            if (!cf.getSuperClassName().equals(IS_SUPER_CLASS)) {

                System.out.printf("\tSuper class: %s\n",
                        cf.getSuperClassName());

                superClassList.add(cf.getSuperClassName());

            } else {
                System.out.printf("\tSuper class: N/A\n");
            }

            for (Method m : cf.getMethods()) {

                System.out.printf("\n\t\tMethod name: %s\n",
                        m.getMethodName());

                if (m.getAttributes().length == 0) {

                    System.out.printf("\t\tMethod calls count: N/A \n");
                } else {

                    for (Attribute a : m.getAttributes()) {

                        if (a.getCodeAttribute() != null) {

                            System.out.printf("\t\tMethod calls count: %s\n",
                                    a.getCodeAttribute().getInvokeCountPerMethod());

                            if (a.getCodeAttribute().getInvokeCountPerMethod()>0) {

                                System.out.printf("\t\tBeen called method(s): ");

                                for (Object o : a.getCodeAttribute().getBeingCalledMethodSignatures()) {
                                    System.out.printf("%s  ", o.toString());
                                }

                                System.out.printf("\n");
                            }
                        }
                    }
                }

                System.out.printf("\t\tMethod has overridden in these classes: \n");
            }

            averageMethodOverrides = (cf.getMethodsCount() > 0) ? totalMethodOverrides/cf.getMethodsCount() : 0;

            System.out.printf("\n\tAverage method overrides: %.2f ≃ %d per method\n",
                    averageMethodOverrides, Math.round((float)averageMethodOverrides));

            printFooter();
        }
    }

    public void printPolymorphism () {

    }



    /**
     * Prints the file name and class name at top
     */
    private void printHeader (ClassFile cf) {

            System.out.printf("\nFile name: %s\n",
                    cf.getFilename());

            System.out.printf("\n\tClass name: %s\n",
                    cf.getFilename().substring(cf.getFilename().lastIndexOf("/") + 1, cf.getFilename().lastIndexOf(".")));
    }



    /**
     * Print a 80 char line at bottom
     */
    private void printFooter () {

        System.out.println("\n================================================================================");

    }

}
